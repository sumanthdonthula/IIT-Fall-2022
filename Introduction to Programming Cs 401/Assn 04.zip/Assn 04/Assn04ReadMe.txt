We have 2 classes Stack.java and main.java

Stack.java:

Stack class is used in initiating the variables and methods associated with it.

The main steps involved in Stack class is :

1) Initiate the ArrayList and top as Variables
2) Create a Push method to push elments into stack.
3) Created a Pop method to remove top element from stack.
4) Created a Peek method to return the top most element

main.java:

main class is used to perform and implement methods over the Stack class. 

The main steps involved in main class is :

1)Created an instance of the Stack
2)Scanning the employee details with help of stringbuffer
3)Pushing the elements from file to Stack using a while loop.
4)Performing Peek operation on Stack
5)Performing Pop operation on Stack
6)Performing Pop operation on Stack
7)Performing Peek operation on Stack

