import java.util.Scanner;

public class main {
	public static void main(String[] args) { 
	    Scanner scan  = new Scanner(System.in);  
	    System.out.print("Please enter the radius : ");	 
		float radius = scan.nextFloat(); 			//Scanning the input value for Radius
		scan.close();								//Closing Scanner
		circle Circle = new circle();				//Initiating the Circle object from Circle class 
		Circle.setRadius(radius);					//Setting the radius value
		System.out.println("Radius : "+Circle.getRadius()); //Printing Radius with getRadius method
		System.out.println("Area   : " +Circle.getArea());	 //Printing Area with getArea method
		System.out.println(Circle.toString());				 //Printing the Summary with toString method		
		}
}
