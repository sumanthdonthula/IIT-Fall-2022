//Creating a Circle class

public class circle {
	float radius; //initiating radius

//Method to Set a value for Radius	
	
	public void setRadius(float r) {
		this.radius= r;  			
	}

//Method to return value of Radius	

	public float getRadius() {
		return this.radius; 					
	}

//Method to calculate Area	

	public float getArea(){
		return (float) (3.14*radius*radius);	
	}

//Method to print the summary	

	public String toString() {
		 return "Area of Circle with a radius "
		 + "of "+radius+" units is "+this.getArea()
		 + " Squared Units"; 
		
	}
		
	}
