We have 2 classes circle.java and main.java

circle.java:

circle class is used in initiating the variables and methods associated with it.

The main steps involved in circle class is :

1) Initiate the instance variable called radius
2) Added setters and getters for the variable radius
3) Created a getArea method which will accept the radius value as an input arguement and
calculates area
4) Created a toString method which will summarises the result.

main.java:

main class is used to get the values of radius using scanner and calling the methods associated with circle class

The main steps involved in main class is :

1)Scanning the radius value using a scanner
2)Created an instance of the circle class
3)Passed the radius value to the object
4)Returned the area of the circle

