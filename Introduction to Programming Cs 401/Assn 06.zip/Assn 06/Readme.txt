1.Fixed Front Method :

We have 2 classes fixedFrontQueue.java and fixedFrontQueuemain.java

fixedFrontQueue.java:

fixedFrontQueue class is used in initiating the variables and methods associated with it.

The main steps involved in fixedFrontQueue class is :

1) Initiate the Array,front and rear as Variables
2) Create a enqueue method to push elments into queue .
3) Created a dequeue method to remove top element from queue.
4) Created a printElements method to return the elements of queue.

fixedFrontQueuemain.java:

main class is used to perform and implement methods over the Queue class. 

The main steps involved in main class is :

1)Created an instance of the fixedFrontQueue class
2)Scanning the employee details with help of stringbuffer
3)Pushing the elements from file to Queue using a while loop.
4)Printing Elements in Queue
5)Performing Enqueue operation on Queue
6)Performing Enqueue operation on Queue
7)Printing Elements in Queue


2.Floating Front Method :

We have 2 classes floatingFrontQueue.java and floatingFrontQueuemain.java

floatingFrontQueue.java:

floatingFrontQueue class is used in initiating the variables and methods associated with it.

The main steps involved in floatingFrontQueue class is :

1) Initiate the Array,front and rear as Variables
2) Create a enqueue method to push elments into queue .
3) Created a dequeue method to remove top element from queue.
4) Created a printElements method to return the elements of queue.

floatingFrontQueuemain.java:

main class is used to perform and implement methods over the Queue class. 

The main steps involved in main class is :

1)Created an instance of the floatingFrontQueue class
2)Scanning the employee details with help of stringbuffer
3)Pushing the elements from file to Queue using a while loop.
4)Printing Elements in Queue
5)Performing Enqueue operation on Queue
6)Performing Enqueue operation on Queue
7)Printing Elements in Queue