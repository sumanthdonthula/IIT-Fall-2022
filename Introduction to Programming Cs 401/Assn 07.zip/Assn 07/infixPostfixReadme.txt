Problem 2:

It has two classes infixPostfix.java and infixPostfixmain.java and it uses stack class. 

infixPostfix.java
1)It conains infixToPostfix method which will initiate a string and add operands and operators into the postfix format using the priorityOrder method and creates a postfix string.
2)It also contains evaluatePostfix Method to evaluate the postfix expression

infixPostfixmain.java
1)Initiate Scanner and read the infix expression
2)Initiate the infixPostFix class and pass the string to convert into postfix using
infixToPostfix method
3)Evaluate the postfix expression and give the result
