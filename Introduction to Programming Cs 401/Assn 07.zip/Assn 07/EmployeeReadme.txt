Problem 1

Problem 1 has two classes Employee.java and Employemain.java.

Employee.java

1)Employee class has setters and getters to set Name and Id
2)It contains selection sort method which uses Id to sort
3)It contains Binary Search method to implement the scanning of elements using recursion.

Employeemain.java
1)Create an Array of Employee type
2)Read the emp.txt file and create employee objects and add them to Employee Array
3)Again initiate the employee class and call selection sort to sort the Values based on IDs
4)Call the Binary search method to check if the Id is present in the Array or not and return the index.