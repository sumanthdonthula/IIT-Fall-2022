Problem 3

Palindrome has two classes palindrome.java and palindromemain.java and it uses stack.java for implementing stack.

palindrome.java:

1)Create a new Stack array using Stack.java
2)Creating isPalindrome method which reads the String by every character and adding it to stack by push method and create a reverse string using pop operator of stack.
3)Returning Boolean as true if the String is a Palindrome

palinromemain.java:

1)Initiating scanner and reading the value of string
2)closing scanner
3)Creating an object p of paliindrome class
4)Calling isPalindrome method to check whether string is palindrome or not.